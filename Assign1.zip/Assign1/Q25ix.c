#include <stdio.h>

int main(void) {
    int n;
    printf("Enter number: ");
    scanf("%d", &n);
    
    for (int i = 0; i < n; i++) {
        int num = n - i;
        int count = n - i;
        
        for (int j = 0; j < i; j++) printf(" ");
        
        for (int j = 0; j < count; j++) {
            printf("%d", num);
            if (j < count - 1) printf(" ");
        }
        printf("\n");
    }
    
    return 0;
}