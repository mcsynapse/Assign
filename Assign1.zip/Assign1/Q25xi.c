#include <stdio.h>

int main(void)
{
    int n;
    printf("Enter the number of rows: ");
    scanf("%d", &n);

    int totalRows = 2 * n - 1;

    for (int i = 0; i < totalRows; i++)
    {
        int rowNum = (i < n) ? i : (totalRows - 1 - i);

        for (int j = 0; j < rowNum; j++)
        {
            printf(" ");
        }

        for (int j = 1; j <= n - rowNum; j++)
        {
            printf("%d", j);
        }

        for (int j = n - rowNum - 1; j >= 1; j--)
        {
            printf("%d", j);
        }

        printf("\n");
    }

    return 0;
}