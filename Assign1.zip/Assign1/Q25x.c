#include <stdio.h>

int main(void) {
    int n;
    printf("Enter the number of rows: ");
    scanf("%d", &n);
    
    int totalRows = 2 * n - 1;
    
    for (int i = 0; i < totalRows; i++) {
        int rowNum = (i < n) ? i + 1 : totalRows - i;
        int spaces = n - rowNum + 1;
        
        for (int j = 0; j < spaces; j++) printf(" ");
        
        for (int j = n; j >= spaces; j--) printf("%d", j);
        
        for (int j = spaces + 1; j <= n; j++) printf("%d", j);
        
        printf("\n");
    }
    
    return 0;
}