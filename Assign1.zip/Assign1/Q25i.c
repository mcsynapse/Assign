#include <stdio.h>

int main(void) {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    
    for (int i = 1; i <= n; i++) {
        for (int j = i; j > 0; j--) {
            printf("%d", j);
        }
        printf("\n");
    }
    
    return 0;
}