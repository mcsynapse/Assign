#include <stdio.h>

int main(void) {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    
    int num = 1;
    
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < n - i; j++) printf(" ");
        
        for (int j = 1; j <= i; j++) {
            printf("%d ", num++);
        }
        printf("\n");
    }
    
    return 0;
}