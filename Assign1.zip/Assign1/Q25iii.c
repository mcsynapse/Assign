#include <stdio.h>

int main(void) {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%c", (j < i) ? ' ' : '*');
        }
        printf("\n");
    }
    
    return 0;
}