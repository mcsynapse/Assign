#include <stdio.h>

long long factorialTail(int n, long long accumulator)
{
    if (n <= 1)
        return accumulator;
    return factorialTail(n - 1, n * accumulator);
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Factorial: %lld\n", factorialTail(n, 1));
    return 0;
}
