#include <stdio.h>

int getLength(char str[])
{
    int i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return i;
}

int countWordOccurrences(char sentence[], char word[])
{
    int i, j, found;
    int count = 0;
    int sLen = getLength(sentence);
    int wLen = getLength(word);

    for (i = 0; i <= sLen - wLen; i++)
    {

        found = 1;
        for (j = 0; j < wLen; j++)
        {
            if (sentence[i + j] != word[j])
            {
                found = 0;
                break;
            }
        }
        if (found == 1)
        {

            int startCheck = (i == 0) || (sentence[i - 1] == ' ');

            char nextChar = sentence[i + wLen];
            int endCheck =
                (nextChar == ' ' || nextChar == '\0' || nextChar == '.' || nextChar == ',');

            if (startCheck && endCheck)
            {
                count++;
            }
        }
    }

    return count;
}

int main()
{
    char sentence[200];
    char word[50];
    int occurrences;

    printf("Enter the sentence: ");
    scanf("%[^\n]", sentence);

    int c;
    while ((c = getchar()) != '\n' && c != EOF)
        ;

    printf("Enter the word to search: ");
    scanf("%s", word);

    occurrences = countWordOccurrences(sentence, word);

    printf("The word '%s' occurs %d times.\n", word, occurrences);

    return 0;
}
