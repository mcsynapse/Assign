#include <stdio.h>

int main()
{
    long int decimalNumber;
    int remainder;
    int i = 0, j;
    char hexNumber[100];

    printf("Enter a decimal number: ");
    scanf("%ld", &decimalNumber);

    if (decimalNumber == 0)
    {
        printf("Hexadecimal: 0\n");
        return 0;
    }

    while (decimalNumber != 0)
    {
        remainder = decimalNumber % 16;

        if (remainder < 10)
        {
            hexNumber[i] = remainder + '0';
        }
        else
        {
            hexNumber[i] = remainder + 55;
        }

        decimalNumber = decimalNumber / 16;
        i++;
    }

    printf("Hexadecimal: ");
    for (j = i - 1; j >= 0; j--)
    {
        printf("%c", hexNumber[j]);
    }
    printf("\n");

    return 0;
}