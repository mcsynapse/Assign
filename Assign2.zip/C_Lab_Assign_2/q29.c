#include <stdio.h>

void reverseIndividualWords(char str[])
{
    char wordBuffer[100];
    int i = 0;
    int k = 0;

    printf("Output: ");

    while (str[i] != '\0')
    {

        if (str[i] != ' ')
        {
            wordBuffer[k] = str[i];
            k++;
        }
        else
        {
            while (k > 0)
            {
                k--;
                printf("%c", wordBuffer[k]);
            }

            printf(" ");
        }
        i++;
    }

    while (k > 0)
    {
        k--;
        printf("%c", wordBuffer[k]);
    }
    printf("\n");
}

int main()
{
    char sentence[200];

    printf("Enter sentence: ");
    scanf("%[^\n]", sentence);

    reverseIndividualWords(sentence);

    return 0;
}
