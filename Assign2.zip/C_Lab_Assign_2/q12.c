#include <stdio.h>

void printTranspose(int matrix[100][100], int m, int n)
{
    int i, j;

    for (j = 0; j < n; j++)
    {
        for (i = 0; i < m; i++)
        {

            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int matrix[100][100];
    int m, n;
    int i, j;

    printf("Enter rows (m) and columns (n): ");
    scanf("%d %d", &m, &n);

    if (m > 100 || n > 100)
    {
        printf("Dimensions must be <= 100.\n");
        return 1;
    }

    printf("Enter the matrix elements:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("\nTranspose of the matrix:\n");
    printTranspose(matrix, m, n);

    return 0;
}
