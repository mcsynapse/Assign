#include <stdio.h>

int* swap(int arr[], int size) {
    int i;
    int min_index = 0;
    int max_index = 0;
    int temp;

    for (i = 1; i < size; i++) {
        if (arr[i] < arr[min_index]) {
            min_index = i;
        }
        if (arr[i] > arr[max_index]) {
            max_index = i;
        }
    }

    temp = arr[min_index];
    arr[min_index] = arr[max_index];
    arr[max_index] = temp;

    return arr;
}

int main() {
    int arr[20];
    int i;
    int* result_ptr;

    printf("Enter 20 integers:\n");
    for (i = 0; i < 20; i++) {
        scanf("%d", &arr[i]);
    }

    result_ptr = swap(arr, 20);

    printf("\nArray after swapping Lowest and Highest elements:\n");
    for (i = 0; i < 20; i++) {
        printf("%d ", result_ptr[i]);
    }
    printf("\n");

    return 0;
}