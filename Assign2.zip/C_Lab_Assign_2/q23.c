#include <stdio.h>

int stringToInt(char str[])
{
    int i = 0;
    int result = 0;
    int sign = 1;

    if (str[0] == '-')
    {
        sign = -1;
        i++;
    }
    else if (str[0] == '+')
    {
        i++;
    }

    while (str[i] != '\0')
    {
        if (str[i] >= '0' && str[i] <= '9')
        {

            result = result * 10 + (str[i] - '0');
        }
        else
        {
            break;
        }
        i++;
    }

    return result * sign;
}

int main()
{
    char input[20];
    int number;

    printf("Enter a number string: ");
    scanf("%s", input);

    number = stringToInt(input);

    printf("Integer value: %d\n", number);

    printf("Value + 10: %d\n", number + 10);

    return 0;
}
