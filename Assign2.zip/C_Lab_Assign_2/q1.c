#include <stdio.h>

int main()
{
    int arr[10];
    int i;
    int smallest, second_smallest;
    int found_second = 0;

    printf("Enter 10 integers:\n");
    for (i = 0; i < 10; i++)
    {
        printf("Enter element %d: ",i+1);
        scanf("%d", &arr[i]);
    }

    smallest = arr[0];
    for (i = 1; i < 10; i++)
    {
        if (arr[i] < smallest)
        {
            smallest = arr[i];
        }
    }

    for (i = 0; i < 10; i++)
    {
        if (arr[i] > smallest)
        {

            if (found_second == 0 || arr[i] < second_smallest)
            {
                second_smallest = arr[i];
                found_second = 1;
            }
        }
    }

    if (found_second)
    {
        printf("The second smallest element is: %d\n", second_smallest);
    }
    else
    {
        printf("There is no second smallest element (all numbers are equal).\n");
    }

    return 0;
}
