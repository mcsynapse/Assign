#include <stdio.h>

void selectionSort(int arr[], int n) 
{
    int i, j, min_idx, temp;

    for (i = 0; i < n - 1; i++) 
    {
        min_idx = i;
        for (j = i + 1; j < n; j++) 
        {
            if (arr[j] < arr[min_idx]) 
            {
                min_idx = j;
            }
        }

        if (min_idx != i) 
        {
            temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }
    }
}

int main() 
{
    int arr[100];
    int n, i;
    int max_element, frequency = 0;

    printf("Enter number of elements (n): ");
    scanf("%d", &n);

    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }

    selectionSort(arr, n);

    printf("\nSorted Array (Ascending): ");
    for (i = 0; i < n; i++) 
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    max_element = arr[n - 1];

    for (i = n - 1; i >= 0; i--) 
    {
        if (arr[i] == max_element) 
        {
            frequency++;
        } 
        else 
        {
            break; 
        }
    }

    printf("The highest element is: %d\n", max_element);
    printf("Frequency of %d is: %d\n", max_element, frequency);

    return 0;
}