#include <stdio.h>

int isDiagonal(int mat[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (i != j && mat[i][j] != 0)
            {
                return 0;
            }
        }
    }
    return 1;
}

int isUpperTriangular(int mat[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (i > j && mat[i][j] != 0)
            {
                return 0;
            }
        }
    }
    return 1;
}

int isLowerTriangular(int mat[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (i < j && mat[i][j] != 0)
            {
                return 0;
            }
        }
    }
    return 1;
}

int main()
{
    int mat[3][3];
    int i, j;

    printf("Enter elements of 3x3 matrix:\n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    printf("\nResults:\n");

    if (isDiagonal(mat))
        printf("i)   It IS a Diagonal Matrix.\n");
    else
        printf("i)   It is NOT a Diagonal Matrix.\n");

    if (isUpperTriangular(mat))
        printf("ii)  It IS an Upper Triangular Matrix.\n");
    else
        printf("ii)  It is NOT an Upper Triangular Matrix.\n");

    if (isLowerTriangular(mat))
        printf("iii) It IS a Lower Triangular Matrix.\n");
    else
        printf("iii) It is NOT a Lower Triangular Matrix.\n");

    return 0;
}
