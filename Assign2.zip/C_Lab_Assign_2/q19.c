#include <stdio.h>

void analyzeSentence(char str[])
{
    int vowels = 0;
    int digits = 0;
    int words = 0;
    int i = 0;
    int in_word = 0; 

    while (str[i] != '\0')
    {
        char ch = str[i];

        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' ||
            ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
        {
            vowels++;
        }

        else if (ch >= '0' && ch <= '9')
        {
            digits++;
        }

        if (ch != ' ' && ch != '\t' && ch != '\n')
        {
            if (in_word == 0)
            {
                words++;
                in_word = 1;
            }
        }
        else
        {
            in_word = 0;
        }

        i++;
    }

    printf("\nAnalysis:\n");
    printf("Vowels: %d\n", vowels);
    printf("Digits: %d\n", digits);
    printf("Words : %d\n", words);
}

int main()
{
    char sentence[200];

    printf("Enter a sentence: ");
    scanf("%[^\n]", sentence);

    analyzeSentence(sentence);

    return 0;
}
