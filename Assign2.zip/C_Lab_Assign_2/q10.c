#include <stdio.h>

void printPascalTriangle(int n)
{
    int line, i;
    long int value;

    for (line = 1; line <= n; line++)
    {
        value = 1;

        for (i = 1; i <= line; i++)
        {
            printf("%ld ", value);

            value = value * (line - i) / i;
        }
        printf("\n");
    }
}

int main()
{
    int n;

    printf("Enter number of rows: ");
    scanf("%d", &n);

    printPascalTriangle(n);

    return 0;
}