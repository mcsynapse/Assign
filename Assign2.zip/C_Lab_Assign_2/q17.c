#include <stdio.h>

int isPalindrome(char str[])
{
    int start = 0;
    int end = 0;

    while (str[end] != '\0')
    {
        end++;
    }
    end--;

    while (start < end)
    {
        if (str[start] != str[end])
        {
            return 0;
        }
        start++;
        end--;
    }

    return 1;
}

int main()
{
    char word[100];

    printf("Enter a word: ");
    scanf("%s", word);

    if (isPalindrome(word))
    {
        printf("Output: Palindrome\n");
    }
    else
    {
        printf("Output: Not Palindrome\n");
    }

    return 0;
}
