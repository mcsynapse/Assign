#include <stdio.h>

void bubbleSort(int arr[], int n) 
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++) 
    {
        for (j = 0; j < n - i - 1; j++) 
        {
            if (arr[j] > arr[j + 1]) 
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int binarySearch(int arr[], int n, int target) 
{
    int low = 0;
    int high = n - 1;
    int mid;

    while (low <= high) 
    {
        mid = (low + high) / 2;

        if (arr[mid] == target) 
        {
            return mid;
        }
        else if (arr[mid] < target) 
        {
            low = mid + 1;
        }
        else 
        {
            high = mid - 1;
        }
    }
    return -1;
}

int main() 
{
    int arr[100];
    int n, m, i;
    int result_index;

    printf("Enter number of elements (n): ");
    scanf("%d", &n);

    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }

    bubbleSort(arr, n);

    printf("\nSorted Array: ");
    for (i = 0; i < n; i++) 
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    printf("\nEnter the element to search (m): ");
    scanf("%d", &m);

    result_index = binarySearch(arr, n, m);

    if (result_index != -1) 
    {
        printf("Element %d found at index %d (position %d).\n", m, result_index, result_index + 1);
    } 
    else 
    {
        printf("Element %d is NOT present in the array.\n", m);
    }

    return 0;
}