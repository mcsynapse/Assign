#include <stdio.h>

long long hexToDecimal(char hex[])
{
    long long decimal = 0;
    int i = 0;
    int digitValue;

    while (hex[i] != '\0')
    {

        if (hex[i] >= '0' && hex[i] <= '9')
        {
            digitValue = hex[i] - '0';
        }
        else if (hex[i] >= 'A' && hex[i] <= 'F')
        {
            digitValue = hex[i] - 55;
        }
        else if (hex[i] >= 'a' && hex[i] <= 'f')
        {
            digitValue = hex[i] - 87;
        }
        else
        {
            break;
        }

        decimal = decimal * 16 + digitValue;

        i++;
    }

    return decimal;
}

int main()
{
    char hexString[20];
    long long result;

    printf("Enter a hexadecimal number: ");
    scanf("%s", hexString);

    result = hexToDecimal(hexString);

    printf("Decimal: %lld\n", result);

    return 0;
}
