#include <stdio.h>

void decimalToBinary(long int n)
{
    int binaryNum[64];
    int i = 0;
    int j;

    if (n == 0)
    {
        printf("0");
        return;
    }

    while (n > 0)
    {
        binaryNum[i] = n % 2;
        n = n / 2;
        i++;
    }

    for (j = i - 1; j >= 0; j--)
    {
        printf("%d", binaryNum[j]);
    }
}

int main()
{
    long int num;

    printf("Enter a decimal number: ");
    scanf("%ld", &num);

    printf("Binary: ");
    decimalToBinary(num);
    printf("\n");

    return 0;
}
