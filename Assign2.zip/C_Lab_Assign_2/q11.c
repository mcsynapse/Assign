#include <stdio.h>

int checkUniqueDigits(long int n)
{
    int seen[10];
    int i;
    int digit;

    for (i = 0; i < 10; i++)
    {
        seen[i] = 0;
    }

    if (n < 0)
        n = -n;

    if (n == 0)
        return 1;

    while (n != 0)
    {
        digit = n % 10;

        if (seen[digit] == 1)
        {
            return 0;
        }

        seen[digit] = 1;

        n = n / 10;
    }

    return 1;
}

int main()
{
    long int num;
    int isUnique;

    printf("Enter a number: ");
    scanf("%ld", &num);

    isUnique = checkUniqueDigits(num);

    if (isUnique)
    {
        printf("Output: Unique\n");
    }
    else
    {
        printf("Output: Not unique\n");
    }

    return 0;
}
