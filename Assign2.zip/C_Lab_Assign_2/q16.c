#include <stdio.h>

void removeMultipleSpaces(char str[])
{
    int read_ptr = 0;
    int write_ptr = 0;

    while (str[read_ptr] != '\0')
    {

        if (str[read_ptr] == ' ' && str[read_ptr + 1] == ' ')
        {
            read_ptr++;
        }
        else
        {
            str[write_ptr] = str[read_ptr];
            read_ptr++;
            write_ptr++;
        }
    }

    str[write_ptr] = '\0';
}

int main()
{
    char sentence[200];

    printf("Enter a sentence: ");
    scanf("%[^\n]", sentence);

    removeMultipleSpaces(sentence);

    printf("Output: %s\n", sentence);

    return 0;
}
