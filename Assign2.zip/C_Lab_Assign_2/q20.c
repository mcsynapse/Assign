#include <stdio.h>

int prime(int n)
{
    int i;

    if (n <= 1)
    {
        return 0;
    }

    for (i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 0; 
        }
    }

    return 1; 
}

int main()
{
    int n, temp, reversed = 0, remainder;
    int isOriginalPrime, isReversedPrime;

    printf("Enter a number: ");
    scanf("%d", &n);

    isOriginalPrime = prime(n);

    temp = n;
    while (temp != 0)
    {
        remainder = temp % 10;
        reversed = reversed * 10 + remainder;
        temp = temp / 10;
    }

    isReversedPrime = prime(reversed);

    if (isOriginalPrime == 1 && isReversedPrime == 1)
    {
        printf("Twisted Prime\n");
    }
    else
    {
        printf("Not Twisted Prime\n");
    }

    return 0;
}
