#include <stdio.h>

void copyString(char src[], char dest[], int index)
{
    dest[index] = src[index];
    if (src[index] == '\0')
        return;
    copyString(src, dest, index + 1);
}

int main()
{
    char src[100], dest[100];
    printf("Enter string: ");
    scanf("%s", src);
    copyString(src, dest, 0);
    printf("Copied string: %s\n", dest);
    return 0;
}
