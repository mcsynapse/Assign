#include <stdio.h>

int my_strcmp(char s1[], char s2[])
{
    int i = 0;
    while (s1[i] != '\0' || s2[i] != '\0')
    {
        if (s1[i] != s2[i])
        {
            return s1[i] - s2[i];
        }
        i++;
    }
    return 0;
}

void my_strcpy(char dest[], char src[])
{
    int i = 0;
    while (src[i] != '\0')
    {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

void sortNames(char arr[][50], int n)
{
    int i, j, min_idx;
    char temp[50];

    for (i = 0; i < n - 1; i++)
    {
        min_idx = i;

        for (j = i + 1; j < n; j++)
        {
            if (my_strcmp(arr[j], arr[min_idx]) < 0)
            {
                min_idx = j;
            }
        }

        if (min_idx != i)
        {
            my_strcpy(temp, arr[i]);
            my_strcpy(arr[i], arr[min_idx]);
            my_strcpy(arr[min_idx], temp);
        }
    }
}

int main()
{
    char names[50][50];
    int n, i;

    printf("Enter number of names: ");
    scanf("%d", &n);

    char dump;
    scanf("%c", &dump);

    printf("Enter %d names:\n", n);
    for (i = 0; i < n; i++)
    {
        scanf("%[^\n]%*c", names[i]);
    }

    sortNames(names, n);

    printf("\nSorted Names:\n");
    for (i = 0; i < n; i++)
    {
        printf("%s\n", names[i]);
    }

    return 0;
}
