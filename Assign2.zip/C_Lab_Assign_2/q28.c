#include <stdio.h>

int main()
{
    char str1[] = "COMPUTER";
    char str2[] = "HELLO";
    int i, j;
    int len1 = 8;
    int len2 = 5;

    // --- Pattern 1 ---
    printf("Pattern 1:\n");
    for (i = len1; i > 0; i--)
    {
        for (j = 0; j < i; j++)
        {
            printf("%c", str1[j]);
        }
        printf("\n");
    }
    printf("\n");

    // --- Pattern 2 ---
    printf("Pattern 2:\n");
    for (i = 0; i < len1; i++)
    {
        for (j = 0; j < i; j++)
        {
            printf(" ");
        }
        for (j = i; j < len1; j++)
        {
            printf("%c", str1[j]);
        }
        printf("\n");
    }
    printf("\n");

    // --- Pattern 3 ---
    printf("Pattern 3:\n");
    for (i = 1; i <= len2; i++)
    {
        for (j = 0; j < i; j++)
        {
            printf("%c", str2[j]);
        }
        printf("\n");
    }
    for (i = len2 - 1; i > 0; i--)
    {
        for (j = 0; j < i; j++)
        {
            printf("%c", str2[j]);
        }
        printf("\n");
    }
    printf("\n");

    // --- Pattern 4 ---
    printf("Pattern 4:\n");
    for (i = 0; i < len1; i++)
    {
        for (j = 0; j < i; j++)
        {
            printf(" ");
        }
        for (j = 0; j < len1 - i; j++)
        {
            printf("%c", str1[j]);
        }
        printf("\n");
    }

    return 0;
}
