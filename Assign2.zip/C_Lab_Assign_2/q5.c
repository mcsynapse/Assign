#include <stdio.h>

void insertionSort(int arr[], int n) 
{
    int i, key, j;

    for (i = 1; i < n; i++) 
    {
        key = arr[i]; 
        j = i - 1;

        while (j >= 0 && arr[j] > key) 
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int main() 
{
    int arr[100];
    int n, i;
    int range;

    printf("Enter number of elements (n): ");
    scanf("%d", &n);

    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }

    insertionSort(arr, n);

    printf("\nSorted Array: ");
    for (i = 0; i < n; i++) 
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    if (n > 0) 
    {
        range = arr[n - 1] - arr[0];
        printf("Difference between Highest (%d) and Lowest (%d) is: %d\n", arr[n - 1], arr[0], range);
    }

    return 0;
}