#include <stdio.h>

void concatAndReverse(char s1[], char s2[])
{
    char combined[200];
    int i = 0;
    int k = 0;

    while (s1[i] != '\0')
    {
        combined[k] = s1[i];
        i++;
        k++;
    }

    combined[k] = ' ';
    k++;

    i = 0;
    while (s2[i] != '\0')
    {
        combined[k] = s2[i];
        i++;
        k++;
    }

    combined[k] = '\0';

    printf("Output: ");
    int j;
    for (j = k - 1; j >= 0; j--)
    {
        printf("%c", combined[j]);
    }
    printf("\n");
}

int main()
{
    char str1[100], str2[100];

    printf("Enter String 1: ");
    scanf("%s", str1);

    printf("Enter String 2: ");
    scanf("%s", str2);

    concatAndReverse(str1, str2);

    return 0;
}
