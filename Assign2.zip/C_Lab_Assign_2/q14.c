#include <stdio.h>

#define MAX 10

void inputMatrix(int mat[MAX][MAX], int row, int col, int matrixNum)
{
    int i, j;
    printf("Enter elements for Matrix %d (%dx%d):\n", matrixNum, row, col);
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }
}

void printMatrix(int mat[MAX][MAX], int row, int col)
{
    int i, j;
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            printf("%d\t", mat[i][j]);
        }
        printf("\n");
    }
}

void addOrSubtract(int mode)
{
    int r1, c1, r2, c2, i, j;
    int a[MAX][MAX], b[MAX][MAX], res[MAX][MAX];

    printf("\nEnter rows and cols for Matrix 1: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and cols for Matrix 2: ");
    scanf("%d %d", &r2, &c2);

    if (r1 != r2 || c1 != c2)
    {
        printf("\nERROR: Dimensions must be identical for Addition/Subtraction.\n");
        return;
    }

    inputMatrix(a, r1, c1, 1);
    inputMatrix(b, r2, c2, 2);

    for (i = 0; i < r1; i++)
    {
        for (j = 0; j < c1; j++)
        {
            if (mode == 1)
                res[i][j] = a[i][j] + b[i][j];
            else
                res[i][j] = a[i][j] - b[i][j];
        }
    }

    printf(mode == 1 ? "\nSum:\n" : "\nDifference:\n");
    printMatrix(res, r1, c1);
}

void multiply()
{
    int r1, c1, r2, c2, i, j, k;
    int a[MAX][MAX], b[MAX][MAX], res[MAX][MAX];

    printf("\nEnter rows and cols for Matrix 1: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and cols for Matrix 2: ");
    scanf("%d %d", &r2, &c2);

    if (c1 != r2)
    {
        printf("\nERROR: Column of 1st must equal Row of 2nd for Multiplication.\n");
        return;
    }

    inputMatrix(a, r1, c1, 1);
    inputMatrix(b, r2, c2, 2);

    for (i = 0; i < r1; i++)
    {
        for (j = 0; j < c2; j++)
        {
            res[i][j] = 0;
            for (k = 0; k < c1; k++)
            {
                res[i][j] += a[i][k] * b[k][j];
            }
        }
    }

    printf("\nProduct:\n");
    printMatrix(res, r1, c2);
}

int main()
{
    int choice;

    while (1)
    {
        printf("\n--- MATRIX OPERATIONS MENU ---\n");
        printf("1. Sum\n");
        printf("2. Difference\n");
        printf("3. Product\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                addOrSubtract(1);
                break;
            case 2:
                addOrSubtract(-1);
                break;
            case 3:
                multiply();
                break;
            case 4:
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }
    return 0;
}
