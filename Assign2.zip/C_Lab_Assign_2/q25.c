#include <stdio.h>

void printFormattedDate(char dateStr[])
{
    const char *months[] = {"",        "January",  "February", "March",  "April",
                            "May",     "June",     "July",     "August", "September",
                            "October", "November", "December"};

    int day = 0, month = 0, year = 0;
    int i = 0;

    while (dateStr[i] != '/' && dateStr[i] != '\0')
    {
        day = day * 10 + (dateStr[i] - '0');
        i++;
    }

    if (dateStr[i] == '/')
        i++;

    while (dateStr[i] != '/' && dateStr[i] != '\0')
    {
        month = month * 10 + (dateStr[i] - '0');
        i++;
    }

    if (dateStr[i] == '/')
        i++;

    while (dateStr[i] != '\0')
    {
        year = year * 10 + (dateStr[i] - '0');
        i++;
    }

    if (month >= 1 && month <= 12)
    {
        printf("Output: %d-%s-%d\n", day, months[month], year);
    }
    else
    {
        printf("Error: Invalid month number (%d)\n", month);
    }
}

int main()
{
    char dateInput[20];

    printf("Enter date (dd/mm/yyyy): ");
    scanf("%s", dateInput);

    printFormattedDate(dateInput);

    return 0;
}
