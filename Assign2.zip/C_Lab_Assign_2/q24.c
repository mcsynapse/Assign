#include <stdio.h>

void findMostFrequentChar(char str[])
{
    int freq[256] = {0};
    int i = 0;
    int max_count = -1;
    char result_char;

    while (str[i] != '\0')
    {
        unsigned char index = (unsigned char) str[i];

        if (str[i] != ' ')
        {
            freq[index]++;
        }
        i++;
    }

    for (i = 0; i < 256; i++)
    {
        if (freq[i] > max_count)
        {
            max_count = freq[i];
            result_char = (char) i;
        }
    }

    if (max_count > 0)
    {
        printf("Most frequent character: '%c' (Occurred %d times)\n", result_char, max_count);
    }
    else
    {
        printf("No characters found.\n");
    }
}

int main()
{
    char input[200];

    printf("Enter a string: ");
    scanf("%[^\n]", input);

    findMostFrequentChar(input);

    return 0;
}
