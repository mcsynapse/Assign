#include <stdio.h>

// 1. Sum of Digits
int sumOfDigits(int n)
{
    if (n == 0)
        return 0;
    return (n % 10) + sumOfDigits(n / 10);
}

// 2. Count Digits
int countDigits(int n)
{
    if (n == 0)
        return 0;
    return 1 + countDigits(n / 10);
}

// 3. GCD of Two Numbers
int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// 4. Power (a^b)
long long power(int base, int exp)
{
    if (exp == 0)
        return 1;
    return base * power(base, exp - 1);
}

// 5. Sum of Series (1 + 2 + ... + n)
int sumSeries(int n)
{
    if (n == 0)
        return 0;
    return n + sumSeries(n - 1);
}

// 6. Factorial (Tail Recursion)
long long factorialTail(int n, long long accumulator)
{
    if (n <= 1)
        return accumulator;
    return factorialTail(n - 1, n * accumulator);
}

// 7. Copy String
void copyString(char src[], char dest[], int index)
{
    dest[index] = src[index];
    if (src[index] == '\0')
        return;
    copyString(src, dest, index + 1);
}

// 8. Reverse String
void reverseString(char str[], int start, int end)
{
    if (start >= end)
        return;
    char temp = str[start];
    str[start] = str[end];
    str[end] = temp;
    reverseString(str, start + 1, end - 1);
}

// 9. Reverse Number
int reverseNumber(int n, int rev)
{
    if (n == 0)
        return rev;
    return reverseNumber(n / 10, rev * 10 + (n % 10));
}

// 10. Fibonacci Series
void printFibonacci(int n, int a, int b)
{
    if (n > 0)
    {
        printf("%d ", a);
        printFibonacci(n - 1, b, a + b);
    }
}

// --- MAIN FUNCTION ---

int main()
{
    int n, a, b, base, exp;
    char str1[100], str2[100];
    int len;

    // --- 1. Sum of Digits ---
    printf("\n=== 1. Sum of Digits ===\n");
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Sum of digits: %d\n", sumOfDigits(n));

    // --- 2. Count Digits ---
    printf("\n=== 2. Count Digits ===\n");
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n == 0)
        printf("Number of digits: 1\n");
    else
        printf("Number of digits: %d\n", countDigits(n));

    // --- 3. GCD ---
    printf("\n=== 3. GCD of Two Numbers ===\n");
    printf("Enter two numbers (a b): ");
    scanf("%d %d", &a, &b);
    printf("GCD of %d and %d: %d\n", a, b, gcd(a, b));

    // --- 4. Power ---
    printf("\n=== 4. Calculate Power (a^b) ===\n");
    printf("Enter base and exponent: ");
    scanf("%d %d", &base, &exp);
    printf("Result: %lld\n", power(base, exp));

    // --- 5. Sum of Series ---
    printf("\n=== 5. Sum of Series (1 to n) ===\n");
    printf("Enter n: ");
    scanf("%d", &n);
    printf("Sum: %d\n", sumSeries(n));

    // --- 6. Factorial ---
    printf("\n=== 6. Factorial (Tail Recursion) ===\n");
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Factorial: %lld\n", factorialTail(n, 1));

    // --- 7. Copy String ---
    printf("\n=== 7. Copy String ===\n");
    printf("Enter source string: ");
    scanf("%s", str1);
    copyString(str1, str2, 0);
    printf("Copied string: %s\n", str2);

    // --- 8. Reverse String ---
    printf("\n=== 8. Reverse String ===\n");
    printf("Enter string to reverse: ");
    scanf("%s", str1);

    // Calculate length manually
    len = 0;
    while (str1[len] != '\0')
        len++;

    reverseString(str1, 0, len - 1);
    printf("Reversed string: %s\n", str1);

    // --- 9. Reverse Number ---
    printf("\n=== 9. Reverse Number ===\n");
    printf("Enter number to reverse: ");
    scanf("%d", &n);
    printf("Reversed number: %d\n", reverseNumber(n, 0));

    // --- 10. Fibonacci Series ---
    printf("\n=== 10. Fibonacci Series ===\n");
    printf("Enter number of terms: ");
    scanf("%d", &n);
    printf("Series: ");
    printFibonacci(n, 0, 1);
    printf("\n");

    return 0;
}
