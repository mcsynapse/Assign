#include <stdio.h>

void printAbbreviated(char name[])
{
    int word_indices[50];
    int count = 0;
    int i = 0;

    while (name[i] != '\0')
    {
        if (name[i] != ' ')
        {
            if (i == 0 || name[i - 1] == ' ')
            {
                word_indices[count] = i;
                count++;
            }
        }
        i++;
    }

    if (count == 0)
        return;

    printf("Output 1: ");

    for (i = 0; i < count - 1; i++)
    {
        printf("%c.", name[word_indices[i]]);
    }

    int last_start = word_indices[count - 1];
    while (name[last_start] != '\0' && name[last_start] != ' ')
    {
        printf("%c", name[last_start]);
        last_start++;
    }
    printf("\n");

    printf("Output 2: ");

    for (i = 0; i < count; i++)
    {
        printf("%c", name[word_indices[i]]);

        if (i < count - 1)
        {
            printf(".");
        }
    }
    printf("\n");
}

int main()
{
    char name[100];

    printf("Enter full name: ");
    scanf("%[^\n]", name);

    printAbbreviated(name);

    return 0;
}
