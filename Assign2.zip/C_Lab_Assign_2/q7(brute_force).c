#include <stdio.h>

int main()
{
    int arr[100];
    int n, i, j;
    int is_duplicate;
    int already_processed;
    int found_any = 0;

    printf("Enter number of elements (n): ");
    scanf("%d", &n);

    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("\nDuplicate elements are: ");

    for (i = 0; i < n; i++)
    {

        already_processed = 0;
        for (j = 0; j < i; j++)
        {
            if (arr[i] == arr[j])
            {
                already_processed = 1;
                break;
            }
        }

        if (already_processed)
        {
            continue;
        }

        is_duplicate = 0;
        for (j = i + 1; j < n; j++)
        {
            if (arr[i] == arr[j])
            {
                is_duplicate = 1;
                break;
            }
        }

        if (is_duplicate)
        {
            printf("%d ", arr[i]);
            found_any = 1;
        }
    }

    if (!found_any)
    {
        printf("None");
    }
    printf("\n");

    return 0;
}
